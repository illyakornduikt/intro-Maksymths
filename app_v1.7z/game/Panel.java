package game;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.*;

public class Panel extends JPanel implements Runnable {
   final int preTileSize = 16; // 16px
   public final int scale = 3;
   public final int postTileSize = preTileSize * scale; // 48px

   public final int maxScreenRow = 9;
   public final int maxScreenCol = 16;

   public final int windowWidth = postTileSize * maxScreenCol; // 768px
   public final int windowHeight = postTileSize * maxScreenRow; // 432px

   Thread time;

   public final int FPS = 60;

   KeyEvents keyHandler = new KeyEvents();

   public static int playerX = 90, playerY = 90;
   public static int playerSpeed = 3;
   public static String direction;

   public Panel() {
      setPreferredSize(new Dimension(windowWidth, windowHeight));
      setBackground(Color.black);
      setDoubleBuffered(true); // for rendering

      timeStart();

      this.addKeyListener(keyHandler);
      this.setFocusable(true);
   }

   private void timeStart() {
      time = new Thread(this);
      time.start();
   }

   @Override
   public void run() {
      double displayInterval = 1000000000 / FPS; // 0.01(6)
      double displayTimes = 0;
      long lastDisplayTime = System.nanoTime();
      long currentTime;

      long delta;

      long stopwatch = 0;
      int drawedTimes = 0;

      while (time != null) {
         currentTime = System.nanoTime();

         delta = currentTime - lastDisplayTime;
         displayTimes = displayTimes + delta / displayInterval;

         stopwatch = stopwatch + delta;

         lastDisplayTime = currentTime;

         if (displayTimes >= 1) {
            update();
            repaint();
            displayTimes--;
            drawedTimes++;
         }

         if (stopwatch >= 1000000000) {
            System.out.print("FPS was: " + drawedTimes + "\n");
            drawedTimes = 0;
            stopwatch = 0;
         }
      }
   }

   public void update() {
      if (keyHandler.moveLeftPressed == true) {
         direction = "left";
         move(direction);
      }
      if (keyHandler.moveRightPressed == true) {
         direction = "right";
         move(direction);
      }
      if (keyHandler.moveTopPressed == true) {
         direction = "top";
         move(direction);
      }
      if (keyHandler.moveBottomPressed == true) {
         direction = "bottom";
         move(direction);
      }
   }

   @Override
   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D) g;

      g2d.setColor(Color.WHITE);
      g2d.fillRect(playerX, playerY, postTileSize, postTileSize);
      g2d.dispose();
   }

   public void move(String direction) {
      switch (direction) {
         case "left" -> playerX -= playerSpeed;
         case "right" -> playerX += playerSpeed;
         case "top" -> playerY -= playerSpeed;
         case "bottom" -> playerY += playerSpeed;
      }
   }
}