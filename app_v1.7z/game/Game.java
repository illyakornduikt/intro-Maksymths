package game;

public class Game {
   private String windowTitle = "Game";

   public Game() {
      new Frame(windowTitle);
   }
}