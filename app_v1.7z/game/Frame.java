package game;

import javax.swing.JFrame;

class Frame extends JFrame {
   Frame(String title) {
      super(title);

      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setResizable(false);
      add(new Panel());

      pack();
      setLocationRelativeTo(null);
      setVisible(true);
   }
}