package game;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyEvents implements KeyListener {
   public boolean moveRightPressed, moveLeftPressed, moveTopPressed, moveBottomPressed;
   // public boolean moveTopRight, moveTopLeft;

   @Override
   public void keyTyped(KeyEvent e) {
      //
   }

   @Override
   public void keyPressed(KeyEvent e) {
      int key = e.getKeyCode();

      if (key == KeyEvent.VK_A || key == KeyEvent.VK_LEFT || key == KeyEvent.VK_KP_LEFT) {
         moveLeftPressed = true;
      }
      if (key == KeyEvent.VK_D || key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_KP_RIGHT) {
         moveRightPressed = true;
      }
      if (key == KeyEvent.VK_W || key == KeyEvent.VK_UP || key == KeyEvent.VK_KP_UP) {
         moveTopPressed = true;
      }
      if (key == KeyEvent.VK_S || key == KeyEvent.VK_DOWN || key == KeyEvent.VK_KP_DOWN) {
         moveBottomPressed = true;
      }
   }

   @Override
   public void keyReleased(KeyEvent e) {
      int key = e.getKeyCode();

      if (key == KeyEvent.VK_A || key == KeyEvent.VK_LEFT || key == KeyEvent.VK_KP_LEFT) {
         moveLeftPressed = false;
      }
      if (key == KeyEvent.VK_D || key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_KP_RIGHT) {
         moveRightPressed = false;
      }
      if (key == KeyEvent.VK_W || key == KeyEvent.VK_UP || key == KeyEvent.VK_KP_UP) {
         moveTopPressed = false;
      }
      if (key == KeyEvent.VK_S || key == KeyEvent.VK_DOWN || key == KeyEvent.VK_KP_DOWN) {
         moveBottomPressed = false;
      }
   }

}
